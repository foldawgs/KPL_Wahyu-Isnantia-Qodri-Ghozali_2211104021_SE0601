﻿using System;

namespace modul13_2211104021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // A & B: Buat dua variabel Singleton
            PusatDataSingleton data1 = PusatDataSingleton.GetDataSingleton();
            PusatDataSingleton data2 = PusatDataSingleton.GetDataSingleton();

            // C: Tambah data anggota kelompok & asisten
            data1.AddSebuahData("Andi - Anggota");
            data1.AddSebuahData("Budi - Anggota");
            data1.AddSebuahData("Sinta - Anggota");
            data1.AddSebuahData("Kak Tya - Asisten");

            // D: Cetak isi data2
            Console.WriteLine("Print dari data2:");
            data2.PrintSemuaData();

            // E: Hapus nama asisten dari data2 (index ke-3)
            data2.HapusSebuahData(3);

            // F: Cetak ulang isi data1
            Console.WriteLine("Print ulang dari data1 setelah penghapusan:");
            data1.PrintSemuaData();

            // G: Tampilkan jumlah elemen dari data1 dan data2
            Console.WriteLine($"Jumlah data di data1: {data1.GetSemuaData().Count}");
            Console.WriteLine($"Jumlah data di data2: {data2.GetSemuaData().Count}");

            Console.ReadLine();
        }
    }
}
