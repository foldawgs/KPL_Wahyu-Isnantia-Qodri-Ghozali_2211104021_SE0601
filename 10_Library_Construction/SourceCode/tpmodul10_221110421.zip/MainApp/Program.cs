﻿using System;
using AljabarLibraries;

namespace MainApp
{
    class Program
    {
        static void Main(string[] args)
        {
            
            double[] akar = Aljabar.AkarPersamaanKuadrat(new double[] { 1, -3, -10 });
            Console.WriteLine("Akar-akar persamaan: " + string.Join(", ", akar));

            
            double[] hasil = Aljabar.HasilKuadrat(new double[] { 2, -3 });
            Console.WriteLine("Hasil kuadrat: " + string.Join(", ", hasil));
        }
    }
}
