﻿using System;
using System.IO;
using Newtonsoft.Json;

class CovidConfig
{
    private const string ConfigFile = "covid_config.json";
    public string SatuanSuhu { get; set; } = "celcius";
    public int BatasHariDeman { get; set; } = 14;
    public string PesanDitolak { get; set; } = "Anda tidak diperbolehkan masuk ke dalam gedung ini";
    public string PesanDiterima { get; set; } = "Anda dipersilahkan untuk masuk ke dalam gedung ini";

    public CovidConfig()
    {
        LoadConfig();
    }

    private void LoadConfig()
    {
        if (File.Exists(ConfigFile))
        {
            string json = File.ReadAllText(ConfigFile);
            var config = JsonConvert.DeserializeObject<CovidConfig>(json);
            SatuanSuhu = config.SatuanSuhu;
            BatasHariDeman = config.BatasHariDeman;
            PesanDitolak = config.PesanDitolak;
            PesanDiterima = config.PesanDiterima;
        }
        else
        {
            SaveConfig();
        }
    }

    public void SaveConfig()
    {
        string json = JsonConvert.SerializeObject(this, Formatting.Indented);
        File.WriteAllText(ConfigFile, json);
    }

    public void UbahSatuan()
    {
        SatuanSuhu = SatuanSuhu == "celcius" ? "fahrenheit" : "celcius";
        SaveConfig();
    }
}

class Program
{
    static void Main()
    {
        CovidConfig config = new CovidConfig();
        Console.WriteLine("Apakah Anda ingin mengganti satuan suhu? (y/n): ");
        if (Console.ReadLine().ToLower() == "y")
        {
            config.UbahSatuan();
            Console.WriteLine("Satuan suhu telah diubah menjadi " + config.SatuanSuhu);
        }

        Console.WriteLine($"Berapa suhu badan anda saat ini? Dalam nilai {config.SatuanSuhu}");
        double suhu = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Berapa hari yang lalu (perkiraan) anda terakhir memiliki gejala demam?");
        int hariDemam = Convert.ToInt32(Console.ReadLine());

        bool suhuValid = (config.SatuanSuhu == "celcius" && suhu >= 36.5 && suhu <= 37.5) ||
                          (config.SatuanSuhu == "fahrenheit" && suhu >= 97.7 && suhu <= 99.5);

        bool hariValid = hariDemam < config.BatasHariDeman;

        Console.WriteLine(suhuValid && hariValid ? config.PesanDiterima : config.PesanDitolak);
    }
}
