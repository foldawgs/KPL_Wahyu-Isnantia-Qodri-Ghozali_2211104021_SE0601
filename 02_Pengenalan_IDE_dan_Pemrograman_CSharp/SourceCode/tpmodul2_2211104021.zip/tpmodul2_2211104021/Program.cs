﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Program
{
    static void Main()
    {
        // Bagian A: Menerima input satu karakter
        Console.Write("Masukkan satu huruf: ");
        char huruf = Char.ToUpper(Console.ReadKey().KeyChar);
        Console.WriteLine();

        // Mengecek apakah huruf adalah vokal atau konsonan
        if (huruf == 'A' || huruf == 'I' || huruf == 'U' || huruf == 'E' || huruf == 'O')
        {
            Console.WriteLine($"Huruf {huruf} merupakan huruf vokal");
        }
        else if (Char.IsLetter(huruf))
        {
            Console.WriteLine($"Huruf {huruf} merupakan huruf konsonan");
        }
        else
        {
            Console.WriteLine("Input bukan huruf yang valid.");
        }

        // Bagian B: Array bilangan genap
        int[] bilanganGenap = { 2, 4, 6, 8, 10 };
        for (int i = 0; i < bilanganGenap.Length; i++)
        {
            Console.WriteLine($"Angka genap {i + 1} : {bilanganGenap[i]}");
        }
    }
}

