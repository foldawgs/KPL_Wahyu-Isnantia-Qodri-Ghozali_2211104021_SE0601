﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Penjumlahan
{
    public dynamic JumlahTigaAngka(dynamic a, dynamic b, dynamic c)
    {
        return a + b + c;
    }
}

class Program
{
    static void Main()
    {
        Penjumlahan penjumlahan = new Penjumlahan();

        // NIM berakhiran 1, maka tipe data input adalah float
        float angka1 = 12.0f;
        float angka2 = 34.0f;
        float angka3 = 56.0f;

        var hasil = penjumlahan.JumlahTigaAngka(angka1, angka2, angka3);
        Console.WriteLine("Hasil Penjumlahan: " + hasil);
    }
}

