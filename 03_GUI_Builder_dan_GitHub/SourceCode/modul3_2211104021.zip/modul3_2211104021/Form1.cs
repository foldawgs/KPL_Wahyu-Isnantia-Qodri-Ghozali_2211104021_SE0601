﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace modul3_2211104021
{
    public partial class Form1: Form
    {
        private int currentValue = 0;
        private int storedValue = 0;
        private bool isAdding = false;
        public Form1()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                Label1.Text = btn.Text;
            }
        }

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            if (int.TryParse(Label1.Text, out currentValue))
            {
                storedValue += currentValue; // Nyimpen angka buat ditambahin nanti
                Label1.Text = ""; // Reset label buat input angka berikutnya
                isAdding = true;
            }
        }


        private void BtnEqual_Click(object sender, EventArgs e)
        {
            if (int.TryParse(Label1.Text, out currentValue) && isAdding)
            {
                storedValue += currentValue; // Nambahin angka terakhir yang ditekan sebelum "="
                Label1.Text = storedValue.ToString(); // Tampilkan hasil
                storedValue = 0; // Reset nilai buat operasi selanjutnya
                isAdding = false;
            }
        }
    }
}