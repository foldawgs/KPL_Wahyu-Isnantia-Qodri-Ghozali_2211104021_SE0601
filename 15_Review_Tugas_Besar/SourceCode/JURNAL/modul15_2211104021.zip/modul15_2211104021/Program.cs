﻿using System;
using System.Linq;

namespace modul15_2211104021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\n=== Secure Login App ===");
                Console.WriteLine("1. Register");
                Console.WriteLine("2. Login");
                Console.WriteLine("3. Exit");
                Console.Write("Pilih menu (1-3): ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Register();
                        break;
                    case "2":
                        Login();
                        break;
                    case "3":
                        Console.WriteLine("Keluar...");
                        return;
                    default:
                        Console.WriteLine("Pilihan tidak valid.");
                        break;
                }
            }
        }

        static void Register()
        {
            Console.Write("Masukkan username: ");
            string username = Console.ReadLine().Trim();

            if (username.Length < 4 || username.Length > 20 || !username.All(char.IsLetter))
            {
                Console.WriteLine("Username harus 4-20 huruf alfabet ASCII saja.");
                return;
            }

            if (UserService.UsernameExists(username))
            {
                Console.WriteLine("Username sudah terdaftar.");
                return;
            }

            Console.Write("Masukkan password: ");
            string password = Console.ReadLine();

            if (!IsPasswordValid(password, username))
            {
                return;
            }

            var user = new User
            {
                Username = username,
                PasswordHash = UserService.HashPassword(password)
            };

            var users = UserService.LoadUsers();
            users.Add(user);
            UserService.SaveUsers(users);

            Console.WriteLine("Registrasi berhasil!");
        }

        static void Login()
        {
            Console.Write("Masukkan username: ");
            string username = Console.ReadLine().Trim();

            Console.Write("Masukkan password: ");
            string password = Console.ReadLine();

            if (UserService.Authenticate(username, password))
            {
                Console.WriteLine("Login berhasil! Selamat datang, " + username);
            }
            else
            {
                Console.WriteLine("Username atau password salah.");
            }
        }

        static bool IsPasswordValid(string password, string username)
        {
            if (password.Length < 8 || password.Length > 20)
            {
                Console.WriteLine("Password harus 8-20 karakter.");
                return false;
            }

            if (!password.Any(char.IsDigit))
            {
                Console.WriteLine("Password harus mengandung minimal 1 angka.");
                return false;
            }

            if (!password.Any(ch => "!@#$%^&*".Contains(ch)))
            {
                Console.WriteLine("Password harus mengandung minimal 1 karakter unik (!@#$%^&*).");
                return false;
            }

            if (password.ToLower().Contains(username.ToLower()))
            {
                Console.WriteLine("Password tidak boleh mengandung username.");
                return false;
            }

            return true;
        }
    }
}
