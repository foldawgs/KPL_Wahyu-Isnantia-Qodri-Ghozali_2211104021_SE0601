﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace modul15_2211104021
{
    internal class UserService
    {
        private static readonly string filePath = "users.json";

        public static List<User> LoadUsers()
        {
            if (!File.Exists(filePath)) return new List<User>();
            string json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<List<User>>(json);
        }

        public static void SaveUsers(List<User> users)
        {
            string json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        public static bool UsernameExists(string username)
        {
            return LoadUsers().Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
        }

        public static bool Authenticate(string username, string password)
        {
            string hash = HashPassword(password);
            return LoadUsers().Any(u => u.Username == username && u.PasswordHash == hash);
        }
    }
}
