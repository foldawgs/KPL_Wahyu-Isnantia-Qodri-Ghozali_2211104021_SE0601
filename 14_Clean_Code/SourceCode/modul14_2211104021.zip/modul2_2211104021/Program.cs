﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraktikumRefactor
{
    class Program
    {
        /// <summary>
        /// Entry point of the application.
        /// </summary>
        static void Main()
        {
            // Section A: Input participant name
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();
            Console.WriteLine($"Welcome, {name}!");

            // Section B: Display array with special rules
            PrintCustomArray();

            // Section C: Check if a number is prime
            Console.Write("Enter a number (1-10000): ");
            int inputNumber = Convert.ToInt32(Console.ReadLine());
            CheckPrimeNumber(inputNumber);
        }

        /// <summary>
        /// Prints an array of numbers from 0 to 19 with custom symbols based on conditions.
        /// </summary>
        static void PrintCustomArray()
        {
            int[] customArray = new int[20];
            for (int i = 0; i < customArray.Length; i++)
            {
                customArray[i] = i;

                if (i % 2 == 0 && i % 3 == 0)
                    Console.WriteLine($"{i} #$#$");
                else if (i % 2 == 0)
                    Console.WriteLine($"{i} ##");
                else if (i % 3 == 0)
                    Console.WriteLine($"{i} $$");
                else
                    Console.WriteLine(i);
            }
        }

        /// <summary>
        /// Checks whether a number is prime and displays the result.
        /// </summary>
        /// <param name="number">The number to check.</param>
        static void CheckPrimeNumber(int number)
        {
            if (IsPrime(number))
                Console.WriteLine($"The number {number} is a prime number.");
            else
                Console.WriteLine($"The number {number} is not a prime number.");
        }

        /// <summary>
        /// Determines whether a number is prime.
        /// </summary>
        /// <param name="number">The number to evaluate.</param>
        /// <returns>True if the number is prime, otherwise false.</returns>
        static bool IsPrime(int number)
        {
            if (number < 2) return false;

            for (int i = 2; i * i <= number; i++)
            {
                if (number % i == 0) return false;
            }

            return true;
        }
    }
}
