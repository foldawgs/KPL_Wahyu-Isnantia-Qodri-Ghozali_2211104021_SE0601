﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main()
    {
        // Section A: Accept one character input
        Console.Write("Enter a letter: ");
        char inputChar = Char.ToUpper(Console.ReadKey().KeyChar);
        Console.WriteLine();

        // Check if the character is a vowel or consonant
        if (inputChar == 'A' || inputChar == 'I' || inputChar == 'U' || inputChar == 'E' || inputChar == 'O')
        {
            Console.WriteLine($"The letter {inputChar} is a vowel.");
        }
        else if (Char.IsLetter(inputChar))
        {
            Console.WriteLine($"The letter {inputChar} is a consonant.");
        }
        else
        {
            Console.WriteLine("Input is not a valid letter.");
        }

        // Section B: Display even numbers from array
        int[] evenNumbers = { 2, 4, 6, 8, 10 };
        for (int i = 0; i < evenNumbers.Length; i++)
        {
            Console.WriteLine($"Even number {i + 1}: {evenNumbers[i]}");
        }
    }
}