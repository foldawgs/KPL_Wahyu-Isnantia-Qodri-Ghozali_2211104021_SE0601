﻿namespace tpmodul12_2211104021
{
    public class FormLogic
    {
        public static string CariTandaBilangan(int a)
        {
            if (a < 0)
                return "Negatif";
            else if (a > 0)
                return "Positif";
            else
                return "Nol";
        }
    }
}
