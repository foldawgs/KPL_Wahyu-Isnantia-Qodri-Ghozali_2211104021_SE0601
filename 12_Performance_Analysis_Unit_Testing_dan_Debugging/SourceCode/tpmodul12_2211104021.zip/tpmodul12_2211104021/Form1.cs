﻿using System;
using System.Windows.Forms;

namespace tpmodul12_2211104021
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCek_Click(object sender, EventArgs e)
        {
            int angka;
            if (int.TryParse(textBoxInput.Text, out angka))
            {
                string hasil = FormLogic.CariTandaBilangan(angka);
                labelOutput.Text = hasil;
            }
            else
            {
                labelOutput.Text = "Input tidak valid!";
            }
        }

        private string CariTandaBilangan(int a)
        {
            if (a < 0)
                return "Negatif";
            else if (a > 0)
                return "Positif";
            else
                return "Nol";
        }
    }
}
