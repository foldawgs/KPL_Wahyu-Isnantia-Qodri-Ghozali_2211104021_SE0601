﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using tpmodul12_2211104021;

namespace tpmodul12_2211104021.Tests
{
    [TestClass]
    public class FormLogicTests
    {
        [TestMethod]
        public void Test_Negatif()
        {
            var result = FormLogic.CariTandaBilangan(-5);
            Assert.AreEqual("Negatif", result);
        }

        [TestMethod]
        public void Test_Positif()
        {
            var result = FormLogic.CariTandaBilangan(10);
            Assert.AreEqual("Positif", result);
        }

        [TestMethod]
        public void Test_Nol()
        {
            var result = FormLogic.CariTandaBilangan(0);
            Assert.AreEqual("Nol", result);
        }
    }
}
