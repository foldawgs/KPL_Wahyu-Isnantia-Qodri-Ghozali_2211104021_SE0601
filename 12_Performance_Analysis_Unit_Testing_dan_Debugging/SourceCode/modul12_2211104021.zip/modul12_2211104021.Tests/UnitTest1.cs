﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using modul12_2211104021;

namespace modul12_NIM.Tests
{
    [TestClass]
    public class HelperTests
    {
        [TestMethod]
        public void Test_PangkatNormal()
        {
            int result = Helper.CariNilaiPangkat(2, 3);
            Assert.AreEqual(8, result);
        }

        [TestMethod]
        public void Test_PangkatNol()
        {
            int result = Helper.CariNilaiPangkat(0, 0);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void Test_PangkatNegatif()
        {
            int result = Helper.CariNilaiPangkat(2, -1);
            Assert.AreEqual(-1, result);
        }

        [TestMethod]
        public void Test_BatasBesar()
        {
            int result = Helper.CariNilaiPangkat(101, 2);
            Assert.AreEqual(-2, result);

            int result2 = Helper.CariNilaiPangkat(2, 11);
            Assert.AreEqual(-2, result2);
        }

        [TestMethod]
        public void Test_Overflow()
        {
            int result = Helper.CariNilaiPangkat(74, 7);
            Assert.AreEqual(-3, result);
        }
    }
}
